#!/usr/bin/env python3
"""
CSE 434 - Socket Programming Project
DHT Peer - Milestone (register, setup-dht, dht-complete)
Group 81 - Port range: 40500-40999

Usage: python3 peer.py <manager-ip> <manager-port>
"""

import socket
import sys
import csv
import os

BUFFER_SIZE = 65536

# Global ring state
local_hash_table = {}
my_id = None
ring_size = None
right_neighbour = None
peer_tuples = []


def is_prime(n):
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True


def next_prime(n):
    """Returns the first prime greater than n."""
    candidate = n + 1
    while not is_prime(candidate):
        candidate += 1
    return candidate


def load_csv(year):
    """Reads details-YYYY.csv and returns a list of record dicts."""
    filename = f"details-{year}.csv"
    if not os.path.exists(filename):
        print(f"[Peer] ERROR: {filename} not found.")
        return None
    records = []
    with open(filename, newline='', encoding='utf-8', errors='replace') as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append(dict(row))
    return records


def send_to_manager(sock, manager_addr, message):
    """Sends a message to the manager and waits for a response."""
    sock.sendto(message.encode(), manager_addr)
    print(f"[Peer] --> Manager: {message}")
    data, _ = sock.recvfrom(BUFFER_SIZE)
    response = data.decode().strip()
    print(f"[Peer] <-- Manager: {response}")
    return response


def send_to_peer(sock, ip, port, message):
    """Sends a UDP message to another peer."""
    sock.sendto(message.encode(), (ip, port))
    print(f"[Peer] --> Peer({ip}:{port}): {message[:120]}")


def handle_peer_message(sock, data):
    """
    Handles an incoming peer-to-peer message.
    Returns False when set-id is received, True otherwise.
    """
    global my_id, ring_size, right_neighbour, peer_tuples, local_hash_table

    message = data.decode().strip()
    print(f"[Peer] <-- Peer: {message[:120]}")
    parts = message.split()
    if not parts:
        return True

    command = parts[0].lower()

    if command == "set-id":
        my_id = int(parts[1])
        ring_size = int(parts[2])
        peer_tuples = []
        idx = 3
        while idx + 2 < len(parts):
            peer_tuples.append((parts[idx], parts[idx+1], int(parts[idx+2])))
            idx += 3
        right_id = (my_id + 1) % ring_size
        _, right_ip, right_port = peer_tuples[right_id]
        right_neighbour = (right_ip, right_port)
        print(f"[Peer] Assigned id={my_id}, ring_size={ring_size}, right_neighbour={right_neighbour}")
        return False

    elif command == "store":
        target_id = int(parts[1])
        pos = int(parts[2])
        record_str = parts[3] if len(parts) > 3 else ""
        if target_id == my_id:
            local_hash_table[pos] = record_str
        else:
            # Forward along the ring
            ip, port = right_neighbour
            send_to_peer(sock, ip, port, message)
        return True

    else:
        print(f"[Peer] Unknown peer command: {command}")
        return True


def leader_setup_dht(sock, manager_addr, n, year, tuples):
    """
    Called after setup-dht SUCCESS.
    1. Sends set-id to all non-leader peers.
    2. Reads CSV and distributes records using two-step hash.
    3. Prints record counts per node.
    4. Sends dht-complete to manager.
    """
    global my_id, ring_size, right_neighbour, peer_tuples, local_hash_table

    my_id = 0
    ring_size = n
    peer_tuples = tuples

    _, right_ip, right_port = peer_tuples[(my_id + 1) % ring_size]
    right_neighbour = (right_ip, right_port)

    # Send set-id to each non-leader peer
    tuples_str = " ".join(f"{name} {ip} {pp}" for name, ip, pp in peer_tuples)
    for i in range(1, n):
        name, ip, pp = peer_tuples[i]
        send_to_peer(sock, ip, pp, f"set-id {i} {n} {tuples_str}")

    # Load CSV and distribute records
    print(f"[Peer/Leader] Loading details-{year}.csv ...")
    records = load_csv(year)
    if records is None:
        print("[Peer/Leader] ABORT: CSV file not found.")
        return

    l = len(records)
    s = next_prime(2 * l)
    print(f"[Peer/Leader] Total records: {l}, hash table size s={s}")

    count = [0] * n
    local_hash_table = {}

    for record in records:
        try:
            event_id = int(record.get("EVENT_ID") or record.get("event_id") or 0)
        except (ValueError, TypeError):
            continue

        pos = event_id % s
        target_id = pos % n
        count[target_id] += 1

        if target_id == my_id:
            local_hash_table[pos] = record
        else:
            fields = list(record.values())
            record_str = "|".join(str(f) for f in fields)
            rip, rport = right_neighbour
            send_to_peer(sock, rip, rport, f"store {target_id} {pos} {record_str}")

    # Print record distribution
    print("\n[Peer/Leader] DHT Record Distribution:")
    for i, (name, _, _) in enumerate(peer_tuples):
        print(f"  Node {i} ({name}): {count[i]} records")
    print()

    # Send dht-complete
    my_name = peer_tuples[0][0]
    response = send_to_manager(sock, manager_addr, f"dht-complete {my_name}")
    if response.startswith("SUCCESS"):
        print("[Peer/Leader] DHT setup complete!")
    else:
        print(f"[Peer/Leader] dht-complete FAILED: {response}")


def peer_wait_for_set_id(sock):
    """Non-leader peer waits for set-id from the leader."""
    print("[Peer] Waiting for set-id from leader...")
    while True:
        data, addr = sock.recvfrom(BUFFER_SIZE)
        if not handle_peer_message(sock, data):
            print("[Peer] Now listening for store commands...")
            peer_listen_for_stores(sock)
            return


def peer_listen_for_stores(sock):
    """
    Listens for store messages.
    Uses a 3-second timeout to detect end of store phase.
    """
    sock.settimeout(3.0)
    while True:
        try:
            data, addr = sock.recvfrom(BUFFER_SIZE)
            handle_peer_message(sock, data)
        except socket.timeout:
            print(f"[Peer] Store phase complete. Stored {len(local_hash_table)} records locally.")
            sock.settimeout(None)
            return


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 peer.py <manager-ip> <manager-port>")
        sys.exit(1)

    manager_ip = sys.argv[1]
    manager_port = int(sys.argv[2])
    manager_addr = (manager_ip, manager_port)

    registered = False
    my_name = None
    sock_m = None
    sock_p = None

    print("[Peer] Ready. Commands: register / setup-dht / wait / exit")

    while True:
        try:
            line = input("> ").strip()
        except EOFError:
            break
        if not line:
            continue

        parts = line.split()
        command = parts[0].lower()

        if command == "register":
            if len(parts) != 5:
                print("Usage: register <name> <IPv4> <m-port> <p-port>")
                continue
            _, peer_name, ip, m_port_s, p_port_s = parts
            m_port = int(m_port_s)
            p_port = int(p_port_s)

            sock_m = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock_m.bind(("", m_port))
            sock_p = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock_p.bind(("", p_port))

            response = send_to_manager(sock_m, manager_addr,
                                       f"register {peer_name} {ip} {m_port} {p_port}")
            if response.startswith("SUCCESS"):
                registered = True
                my_name = peer_name
                print(f"[Peer] Registered as '{my_name}'")
            else:
                sock_m.close()
                sock_p.close()
                sock_m = sock_p = None

        elif command == "setup-dht":
            if not registered:
                print("[Peer] ERROR: must register first")
                continue
            if len(parts) != 4:
                print("Usage: setup-dht <name> <n> <YYYY>")
                continue
            _, peer_name, n_s, yyyy = parts
            n = int(n_s)

            response = send_to_manager(sock_m, manager_addr,
                                       f"setup-dht {peer_name} {n} {yyyy}")
            if not response.startswith("SUCCESS"):
                print(f"[Peer] setup-dht failed: {response}")
                continue

            resp_parts = response.split()
            tuples = []
            idx = 3
            while idx + 2 < len(resp_parts):
                tuples.append((resp_parts[idx], resp_parts[idx+1], int(resp_parts[idx+2])))
                idx += 3

            print("[Peer] setup-dht SUCCESS. Starting DHT construction...")
            leader_setup_dht(sock_p, manager_addr, n, yyyy, tuples)

        elif command == "wait":
            if sock_p is None:
                print("[Peer] ERROR: must register first")
                continue
            peer_wait_for_set_id(sock_p)

        elif command == "exit":
            print("[Peer] Exiting.")
            break

        else:
            print(f"[Peer] Unknown command: {command}")

    if sock_m:
        sock_m.close()
    if sock_p:
        sock_p.close()


if __name__ == "__main__":
    main()